#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f package.json || ! -f public/app.js || ! -f src/game-core.js ]]; then
  echo "Fehler: Bitte diesen Befehl im Hauptordner von neon-snake-arena ausführen."
  exit 1
fi

node apply-update.mjs
npm run check

git add public/app.js public/sw.js src/game-core.js tests/game-core.test.mjs
if git diff --cached --quiet; then
  echo "Keine neuen Änderungen gefunden."
  exit 0
fi

git commit -m "Steuerung und Animation beschleunigen"
git push

rm -f apply-update.mjs README.txt snake-responsiveness-update.zip

echo ""
echo "Fertig: GitHub wurde aktualisiert. Cloudflare veröffentlicht die neue Version automatisch."
rm -f update.sh
