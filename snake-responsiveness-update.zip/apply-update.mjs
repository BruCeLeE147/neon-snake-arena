import fs from "node:fs";

function read(path) {
  if (!fs.existsSync(path)) throw new Error(`Datei fehlt: ${path}`);
  return fs.readFileSync(path, "utf8");
}

function write(path, content) {
  fs.writeFileSync(path, content, "utf8");
}

function replaceOnce(content, search, replacement, label) {
  const first = content.indexOf(search);
  if (first === -1) throw new Error(`Update konnte nicht angewendet werden (${label}). Der Projektstand ist anders als erwartet.`);
  if (content.indexOf(search, first + search.length) !== -1) throw new Error(`Update ist nicht eindeutig (${label}).`);
  return content.slice(0, first) + replacement + content.slice(first + search.length);
}

let app = read("public/app.js");

app = replaceOnce(
  app,
  'const SPEEDS = { relaxed: 150, normal: 112, turbo: 78 };\nconst ROOM_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";',
  'const SPEEDS = { relaxed: 150, normal: 112, turbo: 78 };\nconst INPUT_BUFFER_LIMIT = 3;\nconst SWIPE_THRESHOLD = 13;\nconst MULTIPLAYER_STEP_MS = 110;\nconst ROOM_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";',
  "Konstanten"
);

app = replaceOnce(
  app,
  '    const dpr = Math.min(3, window.devicePixelRatio || 1);',
  '    const dpr = Math.min(2, window.devicePixelRatio || 1);',
  "Canvas-Auflösung"
);

app = replaceOnce(
  app,
  'class GameRenderer {',
  `function renderPlayerBetweenTicks(player, grid) {
  const progress = Math.max(0, Math.min(0.94, Number(player.renderProgress) || 0));
  if (!progress || player.alive === false || !player.body?.length) return player;

  const direction = player.renderDir || player.dir;
  const vector = DIRECTIONS[direction] || DIRECTIONS.right;
  const body = player.body.map((part, index) => {
    const target = index === 0
      ? { x: part.x + vector.x, y: part.y + vector.y }
      : player.body[index - 1];

    const crossesEdge = index === 0 && (
      target.x < 0 || target.y < 0 || target.x >= grid.w || target.y >= grid.h
    );
    if (crossesEdge) return { ...part };

    return {
      x: part.x + (target.x - part.x) * progress,
      y: part.y + (target.y - part.y) * progress
    };
  });

  return { ...player, body, dir: direction };
}

class GameRenderer {`,
  "flüssige Darstellung"
);

app = replaceOnce(
  app,
  '    for (const player of state.players || []) drawSnake(ctx, player, this.metrics, time);',
  '    for (const player of state.players || []) {\n      drawSnake(ctx, renderPlayerBetweenTicks(player, state.grid), this.metrics, time);\n    }',
  "Spieler-Interpolation"
);

app = replaceOnce(
  app,
  '    pendingDir: "right",\n    food: [],',
  '    pendingDir: "right",\n    inputQueue: [],\n    food: [],',
  "Solo-Eingabepuffer"
);

app = replaceOnce(
  app,
  '  if (OPPOSITE[game.dir] !== game.pendingDir) game.dir = game.pendingDir;\n  const vector = DIRECTIONS[game.dir];',
  '  const queuedDirection = game.inputQueue.shift() || game.pendingDir;\n  if (queuedDirection && OPPOSITE[game.dir] !== queuedDirection) game.dir = queuedDirection;\n  game.pendingDir = game.inputQueue[0] || game.dir;\n  const vector = DIRECTIONS[game.dir];',
  "Solo-Richtungsverarbeitung"
);

app = replaceOnce(
  app,
  `function singleRenderState() {
  const game = app.single;
  if (!game) return null;
  return {
    grid: game.grid,
    food: game.food,
    players: [{
      slot: 0,
      name: "Du",
      skin: settings.skin,
      body: game.snake,
      dir: game.dir,
      alive: game.alive,
      score: game.score
    }]
  };
}

function multiplayerRenderState() {
  return app.multi?.state || { grid: { w: 48, h: 28 }, food: [], players: [] };
}`,
  `function singleRenderState(renderProgress = 0) {
  const game = app.single;
  if (!game) return null;
  return {
    grid: game.grid,
    food: game.food,
    players: [{
      slot: 0,
      name: "Du",
      skin: settings.skin,
      body: game.snake,
      dir: game.dir,
      renderDir: game.inputQueue[0] || game.pendingDir || game.dir,
      renderProgress,
      alive: game.alive,
      score: game.score
    }]
  };
}

function multiplayerRenderState(now = performance.now()) {
  const state = app.multi?.state;
  if (!state) return { grid: { w: 48, h: 28 }, food: [], players: [] };

  const elapsed = now - (app.multi.stateReceivedAt || now);
  const renderProgress = state.status === "playing"
    ? Math.min(0.94, Math.max(0, elapsed / MULTIPLAYER_STEP_MS))
    : 0;

  return {
    ...state,
    players: (state.players || []).map((player) => ({
      ...player,
      renderProgress,
      renderDir: player.slot === app.multi.slot
        ? (app.multi.predictedDir || player.dir)
        : player.dir
    }))
  };
}`,
  "Render-Zustände"
);

app = replaceOnce(
  app,
  `function setDirection(direction) {
  if (!DIRECTIONS[direction]) return;
  sound.play("click");
  if (app.mode === "single" && app.single) {
    if (OPPOSITE[app.single.dir] !== direction) app.single.pendingDir = direction;
  } else if (app.mode === "multi" && app.multi?.ws?.readyState === WebSocket.OPEN) {
    app.multi.ws.send(JSON.stringify({ type: "input", direction }));
  }
}`,
  `function queueSingleDirection(direction) {
  const game = app.single;
  if (!game) return false;

  const reference = game.inputQueue.at(-1) || game.pendingDir || game.dir;
  if (direction === reference || OPPOSITE[reference] === direction) return false;
  if (game.inputQueue.length >= INPUT_BUFFER_LIMIT) return false;

  game.inputQueue.push(direction);
  game.pendingDir = game.inputQueue[0];
  return true;
}

function setDirection(direction) {
  if (!DIRECTIONS[direction]) return;
  let accepted = false;

  if (app.mode === "single" && app.single) {
    accepted = queueSingleDirection(direction);
  } else if (app.mode === "multi" && app.multi?.ws?.readyState === WebSocket.OPEN) {
    const own = app.multi.state?.players?.find((player) => player.slot === app.multi.slot);
    const reference = app.multi.predictedDir || own?.dir;
    if (!reference || (direction !== reference && OPPOSITE[reference] !== direction)) {
      app.multi.predictedDir = direction;
      app.multi.ws.send(JSON.stringify({ type: "input", direction }));
      accepted = true;
    }
  }

  if (accepted) sound.play("click");
}`,
  "Eingabepuffer"
);

app = replaceOnce(
  app,
  `  if (app.active && app.mode === "single" && app.single) {
    handleSingleCountdown(now);
    if (app.single.phase === "playing" && !app.single.paused) {
      app.accumulator += dt;
      const acceleration = Math.min(28, Math.floor(app.single.score / 100) * 3);
      const interval = Math.max(55, SPEEDS[settings.speed] - acceleration);
      while (app.accumulator >= interval) {
        moveSingle();
        app.accumulator -= interval;
      }
    }
    renderer.draw(singleRenderState(), now);
  } else if (app.active && app.mode === "multi") {
    renderer.draw(multiplayerRenderState(), now);
  }`,
  `  if (app.active && app.mode === "single" && app.single) {
    handleSingleCountdown(now);
    const acceleration = Math.min(28, Math.floor(app.single.score / 100) * 3);
    const interval = Math.max(55, SPEEDS[settings.speed] - acceleration);

    if (app.single.phase === "playing" && !app.single.paused) {
      app.accumulator += dt;
      while (app.accumulator >= interval) {
        moveSingle();
        app.accumulator -= interval;
      }
    }

    const renderProgress = app.single.phase === "playing" && !app.single.paused
      ? app.accumulator / interval
      : 0;
    renderer.draw(singleRenderState(renderProgress), now);
  } else if (app.active && app.mode === "multi") {
    renderer.draw(multiplayerRenderState(now), now);
  }`,
  "Animationsschleife"
);

app = replaceOnce(
  app,
  '  app.multi = { ws: null, state: null, slot: null, room: normalizedRoom, connected: false };',
  '  app.multi = { ws: null, state: null, slot: null, room: normalizedRoom, connected: false, stateReceivedAt: performance.now(), predictedDir: null };',
  "Multiplayer-Zustand"
);

app = replaceOnce(
  app,
  `  if (message.type === "state") {
    app.multi.state = message;
    updateHud();
    updateMultiplayerCenter(message);
    return;
  }`,
  `  if (message.type === "state") {
    app.multi.state = message;
    app.multi.stateReceivedAt = performance.now();
    const own = message.players?.find((player) => player.slot === app.multi.slot);
    if (own && app.multi.predictedDir === own.dir) app.multi.predictedDir = null;
    updateHud();
    updateMultiplayerCenter(message);
    return;
  }`,
  "Multiplayer-Vorhersage"
);

app = replaceOnce(
  app,
  `let pointerStart = null;
ui.stage.addEventListener("pointerdown", (event) => {
  pointerStart = { x: event.clientX, y: event.clientY, at: performance.now() };
  ui.stage.setPointerCapture?.(event.pointerId);
});
ui.stage.addEventListener("pointerup", (event) => {
  if (!pointerStart) return;
  const dx = event.clientX - pointerStart.x;
  const dy = event.clientY - pointerStart.y;
  const distance = Math.hypot(dx, dy);
  if (distance > 18) {
    setDirection(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "right" : "left") : (dy > 0 ? "down" : "up"));
  }
  pointerStart = null;
});
ui.stage.addEventListener("pointercancel", () => { pointerStart = null; });`,
  `function directionFromDelta(dx, dy) {
  return Math.abs(dx) > Math.abs(dy)
    ? (dx > 0 ? "right" : "left")
    : (dy > 0 ? "down" : "up");
}

let pointerStart = null;
ui.stage.addEventListener("pointerdown", (event) => {
  pointerStart = { x: event.clientX, y: event.clientY };
  ui.stage.setPointerCapture?.(event.pointerId);
});
ui.stage.addEventListener("pointermove", (event) => {
  if (!pointerStart) return;
  const dx = event.clientX - pointerStart.x;
  const dy = event.clientY - pointerStart.y;
  if (Math.hypot(dx, dy) < SWIPE_THRESHOLD) return;

  event.preventDefault();
  setDirection(directionFromDelta(dx, dy));
  pointerStart = { x: event.clientX, y: event.clientY };
});
ui.stage.addEventListener("pointerup", (event) => {
  if (!pointerStart) return;
  const dx = event.clientX - pointerStart.x;
  const dy = event.clientY - pointerStart.y;
  if (Math.hypot(dx, dy) >= SWIPE_THRESHOLD) setDirection(directionFromDelta(dx, dy));
  pointerStart = null;
});
ui.stage.addEventListener("pointercancel", () => { pointerStart = null; });`,
  "sofortige Wischsteuerung"
);

write("public/app.js", app);

let core = read("src/game-core.js");
core = replaceOnce(
  core,
  '    pendingDir: dir,\n    alive: true,',
  '    pendingDir: dir,\n    inputQueue: [],\n    alive: true,',
  "Server-Eingabepuffer"
);

core = replaceOnce(
  core,
  `export function setDirection(player, direction) {
  if (!DIRECTIONS[direction]) return false;
  if (OPPOSITE[player.dir] === direction) return false;
  player.pendingDir = direction;
  return true;
}`,
  `export function setDirection(player, direction) {
  if (!DIRECTIONS[direction]) return false;
  if (!Array.isArray(player.inputQueue)) player.inputQueue = [];

  const reference = player.inputQueue.at(-1) || player.pendingDir || player.dir;
  if (direction === reference || OPPOSITE[reference] === direction) return false;
  if (player.inputQueue.length >= 3) return false;

  player.inputQueue.push(direction);
  player.pendingDir = player.inputQueue[0];
  return true;
}`,
  "Server-Richtungswarteschlange"
);

core = replaceOnce(
  core,
  `    if (!player.alive) continue;
    if (OPPOSITE[player.dir] !== player.pendingDir) player.dir = player.pendingDir;
    const vector = DIRECTIONS[player.dir];`,
  `    if (!player.alive) continue;
    const nextDirection = player.inputQueue?.length
      ? player.inputQueue.shift()
      : player.pendingDir;
    if (nextDirection && OPPOSITE[player.dir] !== nextDirection) player.dir = nextDirection;
    player.pendingDir = player.inputQueue?.[0] || player.dir;
    const vector = DIRECTIONS[player.dir];`,
  "Server-Verarbeitung"
);
write("src/game-core.js", core);

let tests = read("tests/game-core.test.mjs");
if (!tests.includes('test("rapid turns are buffered in order"')) {
  tests += `\n\ntest("rapid turns are buffered in order", () => {\n  const player = createPlayer(0, "A", "neon", grid);\n  assert.equal(setDirection(player, "up"), true);\n  assert.equal(setDirection(player, "left"), true);\n  assert.deepEqual(player.inputQueue, ["up", "left"]);\n\n  stepMultiplayer([player], [], grid, constantRng(0.2));\n  assert.equal(player.dir, "up");\n  assert.equal(player.pendingDir, "left");\n\n  stepMultiplayer([player], [], grid, constantRng(0.2));\n  assert.equal(player.dir, "left");\n});\n`;
}
write("tests/game-core.test.mjs", tests);

let sw = read("public/sw.js");
sw = sw.replace('const CACHE = "neon-snake-arena-v1";', 'const CACHE = "neon-snake-arena-v2-responsive";');
sw = replaceOnce(
  sw,
  `  if (event.request.mode === "navigate") {
    event.respondWith(fetch(event.request).catch(() => caches.match("/index.html")));
    return;
  }

  event.respondWith(`,
  `  if (event.request.mode === "navigate") {
    event.respondWith(fetch(event.request).catch(() => caches.match("/index.html")));
    return;
  }

  if (["/app.js", "/styles.css"].includes(url.pathname)) {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put(event.request, copy));
          return response;
        })
        .catch(() => caches.match(event.request))
    );
    return;
  }

  event.respondWith(`,
  "Service-Worker-Aktualisierung"
);
write("public/sw.js", sw);

console.log("✓ Sofortige Wischsteuerung aktiviert");
console.log("✓ Eingabepuffer für schnelle Kurven ergänzt");
console.log("✓ Bewegung zwischen Rasterfeldern geglättet");
console.log("✓ Multiplayer-Vorhersage ergänzt");
console.log("✓ Canvas-Auflösung für iPhones optimiert");
